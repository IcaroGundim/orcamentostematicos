# Guia da Secretaria — Orçamentos Temáticos

Documento em LaTeX com orientações para os perfis **Representante** (`SECRETARIA_REPRESENTANTE`) e **Revisor interno** (`SECRETARIA_REVISOR`) da plataforma.

## Pré-requisitos

- `pdflatex` (TeX Live ou equivalente)
- Pacotes: `babel`, `hyperref`, `geometry`, `tikz`, `tcolorbox`, `booktabs`, entre outros listados em `preamble.tex`

## Compilar o PDF

```bash
cd docs/guia-secretaria
make pdf
```

O arquivo gerado será `guia-secretaria.pdf`. O Makefile executa `pdflatex` duas vezes para atualizar referências cruzadas e o sumário.

## Limpar artefatos

```bash
make clean
```

## Estrutura

| Arquivo | Descrição |
|---------|-----------|
| `guia-secretaria.tex` | Conteúdo principal (9 seções) |
| `preamble.tex` | Pacotes e caixas de destaque |
| `assets/` | Logotipos institucionais |
| `Makefile` | Alvo `pdf` |

## Sincronização com a plataforma

O conteúdo espelha a página `/secretaria/ajuda` e o código em `apps/web/src/app/secretaria/`. Ao alterar status, classificações ou campos do formulário, atualize este documento e `secretaria-help-content.tsx` em conjunto.
